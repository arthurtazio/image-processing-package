# package_name

Description. 
The package IMAGE_PROCESSING is used to:
    PROCESSING:

	  - HISTOGRAM MATCHING
	  - STRUCTURAL SIMILARY
	  - RESIZE IMAGE
	UTILS:
	  - READ IMAGE
	  - SAVE IMAGE
	  - PLOT IMAGE
	  - PLOT RESULT
	  - PLOT HISTOGRAM
	  


## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install IMAGE_PROCESSING
```

## Author
ARTHUR TAZIO 

## License
[MIT](https://choosealicense.com/licenses/mit/)